# .ind.mom registrar module
This repository will have files for a SparrowHost registry epp client module for WHMCS.
Create a folder and name it 'fred'.
Edit the config.php file with the appropriate data given by the registry.
Copy the folder 'fred' to 'YOUR_PATH_TO_WHMCS/modules/registrars/'
Click then on "Products / Services" => "Domain Registrars"
Enable fred module.

Prepare your certificate file by pasting the private key below the certificate to appear as the sample given... 'cert.pem'.
